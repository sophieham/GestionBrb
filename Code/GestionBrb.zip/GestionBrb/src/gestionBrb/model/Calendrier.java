package gestionBrb.model;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Calendrier
{
	private Reservations reservations;

	public Calendrier(){
		super();
	}

	public void ajoutReservations(Reservations Reservation) {
		// TODO implement me	
	}

	public void modifierReservations(Reservations reservation) {
		// TODO implement me	
	}
	public void afficherCalendrier() {
		// TODO implement me	
	}
	
}

