package gestionBrb.model;

import java.util.Date;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Ticket
{
	private int idTicket;
	private Date dateGeneree;
	private Serveur serveur;

	public Ticket(){
		super();
	}

	public void imprimerTicket() {
		// TODO implement me	
	}
	
}

