package gestionBrb.model;

import java.util.Date;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Reservations
{
	private int idReservation;
	private int numTel;
	private String nom;
	private int nbCouverts;
	private Table tableReservee;
	private String prenom;
	private Date date;
	private String demandeSpe;

	public Reservations(){
		super();
	}

	public void setReservations() {
		// TODO implement me	
	}

	public void getReservations() {
		// TODO implement me	
	}
	
}

