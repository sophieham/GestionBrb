package gestionBrb.model;

import java.util.Date;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Commande extends Ticket
{
	private String idCommande;
	private Produit produitCommande;
	private double prixTotal;
	private Date date;

	public Commande(){
		super();
	}

	public void modifierCommande() {
		// TODO implement me	
	}

	public void voirCommande() {
		// TODO implement me	
	}
	
}

