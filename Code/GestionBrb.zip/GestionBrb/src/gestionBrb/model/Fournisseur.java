package gestionBrb.model;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Fournisseur
{
	private int idFournisseur;
	private String nom;
	private String adresse;
	private int numTel;

	public Fournisseur(){
		super();
	}

}

