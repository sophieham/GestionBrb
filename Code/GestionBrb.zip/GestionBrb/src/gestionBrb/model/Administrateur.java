package gestionBrb.model;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Administrateur extends Utilisateurs
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 */
	public Administrateur(){
		super();
	}

	public void modifierUtilisateurs() {
		// TODO Auto-generated method stub
		
	}

}

