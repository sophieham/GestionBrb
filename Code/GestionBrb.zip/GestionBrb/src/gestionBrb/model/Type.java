package gestionBrb.model;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
public enum Type
{
	Entree, Plat, Dessert; // faire une connexion a la bd pour r�cup�rer tous les types
}
