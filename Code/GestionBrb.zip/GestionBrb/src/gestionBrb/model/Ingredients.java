package gestionBrb.model;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Ingredients
{
	private int idIngredient;
	private String nom;
	private int qteRestante;
	private double prixIngredient;
	private Fournisseur fournisseur;

	public Ingredients(){
		super();
	}

	public void setIngredient() {
		// TODO implement me	
	}

	public void getIngredient() {
		// TODO implement me	
	}

	public void commanderIngredient() {
		// TODO implement me	
	}

	public void estEnStock() {
		// TODO implement me	
	}
	
}

