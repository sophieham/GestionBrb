package gestionBrb.model;

import java.util.Date;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class FactureIngredients
{
	private int idCommande;
	private Date date;
	private double prixTotal;

	public FactureIngredients(){
		super();
	}

}

