package gestionBrb.model;



/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
public abstract class Utilisateurs 
{
    private String identifiant = "";
    private String mot2passe = "";
    private String nom = "";
    private String prenom = "";
    private int privileges = 0;
	
}

