package gestionBrb.model;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Serveur extends Utilisateurs
{
	private int idServeur;

	public Serveur(){
		super();
	}

	public void prendreCommande() {
		// TODO implement me	
	}
	
}

