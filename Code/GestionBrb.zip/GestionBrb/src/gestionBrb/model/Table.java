package gestionBrb.model;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class Table
{
	private int idTable;
	private int nbCouvertsMin;
	private String demandeSpe;
	private Commande commande;
	private int nbCouvertsMax;
	private boolean estOccupe;
	
	public Table(){
		super();
	}

	public void modifierTable() {
		// TODO implement me	
	}

	public void voirTable() {
		// TODO implement me	
	}

	public void setEstOccupe() {
		// TODO implement me	
	}

	public void getEstOccupe() {
		// TODO implement me	
	}

	public void setDemandeSpe() {
		// TODO implement me	
	}

	public void getDemandeSpe() {
		// TODO implement me	
	}
	
}

